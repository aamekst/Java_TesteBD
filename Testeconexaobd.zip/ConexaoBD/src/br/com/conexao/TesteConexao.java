package br.com.conexao;

import java.sql.Connection;

public class TesteConexao {

	public static void main(String[] args) {
		Connection c = null;
		
		try {
			c = new ConexaoFactory() .getConnection();
			System.out.println("Conexão aberta");
			
		}catch(Exception e) {
			System.out.println("Erro na conexão");
			
		}finally {
			try {
				 c.close();
		 
				
			}catch (Exception e){
				System.out.println(e);
				
			}
		}

	}

}
